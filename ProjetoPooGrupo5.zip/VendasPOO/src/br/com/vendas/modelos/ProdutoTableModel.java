
package br.com.vendas.modelos;

import br.com.vendas.bean.Produtos;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;


public class ProdutoTableModel extends AbstractTableModel{

    private List<Produtos> dados = new ArrayList<>();
    private String[] colunas = {"CodProd", "Descrição", "Preço", "Unidade", "Qtde Inicial", "Qtde Atual", "Data Cadastro"};
    
    @Override
    public String getColumnName(int column){
        return colunas[column];
    }
    
    @Override
    public int getRowCount() {
        return dados.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        switch(coluna){
            case 0:
                return dados.get(linha).getCodProd();
            case 1: 
                return dados.get(linha).getDescricao();
            case 2:
                return dados.get(linha).getPreco();
            case 3:
                return dados.get(linha).getUnidade();
            case 4:
                return dados.get(linha).getQtd_inicial();
            case 5:
                return dados.get(linha).getQtd_atual();
            case 6:
                return dados.get(linha).getData();
        }
        
        return null;
    }
    
}
