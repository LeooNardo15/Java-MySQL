
package br.com.vendas.dao;

import br.com.vendas.bean.Itens_Ped;
import br.com.vendas.bean.Pedido;
import br.com.vendas.conexao.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItensDao {
            private final Connection c;
    
    public ItensDao() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    

        public Itens_Ped create(Itens_Ped ped)throws SQLException{
        
        String sql = "INSERT INTO Itens_Ped (CodPed, CodProd, NomeCli, ProdDesc, Quantidade)VALUES(?,?,?,?,?)";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setInt(1, ped.getCodPed());
            stmt.setInt(2, ped.getCodProd());
            stmt.setString(3, ped.getNomeCli());
            stmt.setString(4, ped.getProdDesc());
            stmt.setInt(5, ped.getQtd());
            
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                ped.setCodPed(id);
            }
            stmt.close();
            c.close();
            return ped;
    }
        
        public Itens_Ped alterar(Itens_Ped ped)throws SQLException{
        
        String sql = "UPDATE Itens_Ped SET CodPed=?, CodProd=? ,NomeCli=?, ProdDesc=?, Quantidade=? WHERE CodPed =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setInt(1, ped.getCodPed());
            stmt.setInt(2, ped.getCodProd());
            stmt.setString(3, ped.getNomeCli());
            stmt.setString(4, ped.getProdDesc());
            stmt.setInt(5, ped.getQtd());
            stmt.setInt(6, ped.getCodPed());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                ped.setCodPed(id);
            }
            stmt.close();
            c.close();
            return ped;
    }
        public Itens_Ped excluir(Itens_Ped pro)throws SQLException{
        
        String sql = "DELETE FROM Itens_Ped WHERE CodPed =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


            stmt.setInt(1, pro.getCodPed());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                pro.setCodPed(id);
            }
            stmt.close();
            c.close();
            return pro;
    }
        
        
        public List<Pedido> lista(String codCli) throws SQLException{

        List<Pedido> pro = new ArrayList<>();
        
        String sql = "select * from Pedidos where CodPed like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + codCli + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Pedido pr = new Pedido(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getDate(4));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
    

    
    public List<Itens_Ped> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Itens_Ped> prod = new ArrayList<Itens_Ped>();
        
        String sql = "select * from Itens_Ped";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Itens_Ped pro = new Itens_Ped(
                rs.getInt(1),
                rs.getInt(2),
                rs.getString(3),
                rs.getString(4),
                rs.getInt(5)
            );
            // adiciona o usu à lista de usus
            prod.add(pro);
        }
        
        rs.close();
        stmt.close();
        return prod;
        
    }
}

