
package br.com.vendas.dao;

import br.com.vendas.bean.Produtos;
import br.com.vendas.conexao.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ProdutoDao {
    private final Connection c;
    
    public ProdutoDao() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    

        public Produtos create(Produtos pro)throws SQLException{
        
        String sql = "INSERT INTO Produtos (Descricao,Preco,Unidade,Qtde_inicial,Qtde_atual, Data_cad)VALUES(?,?,?,?,?,?)";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            //stmt = con.prepareStatement("INSERT INTO Clientes (Nome,Ender,Bairro,Cidade,CEP,UF,Email,Fone,Celular)VALUES(?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, pro.getDescricao());
            stmt.setDouble(2, pro.getPreco());
            stmt.setString(3, pro.getUnidade());
            stmt.setInt(4, pro.getQtd_inicial());
            stmt.setInt(5, pro.getQtd_atual());
            stmt.setDate(6, new java.sql.Date(new java.util.Date().getTime()));
            
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                pro.setCodProd(id);
            }
            stmt.close();
            c.close();
            return pro;
    }
        
        public Produtos alterar(Produtos pro)throws SQLException{
        
        String sql = "UPDATE Produtos SET Descricao=?,Preco=?,Unidade=?,Qtde_inicial=?,Qtde_atual=?,Data_cad=? WHERE CodProd =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setString(1, pro.getDescricao());
            stmt.setDouble(2, pro.getPreco());
            stmt.setString(3, pro.getUnidade());
            stmt.setInt(4, pro.getQtd_inicial());
            stmt.setInt(5, pro.getQtd_atual());
            stmt.setDate(6, new java.sql.Date(new java.util.Date().getTime()));
            stmt.setInt(7, pro.getCodProd());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                pro.setCodProd(id);
            }
            stmt.close();
            c.close();
            return pro;
    }
        public Produtos excluir(Produtos pro)throws SQLException{
        
        String sql = "DELETE FROM Produtos WHERE CodProd =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


            stmt.setInt(1, pro.getCodProd());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                pro.setCodProd(id);
            }
            stmt.close();
            c.close();
            return pro;
    }
        
        
        public Produtos busca(Produtos pro) throws SQLException{
        String sql = "select * from Produtos WHERE CodProd = ?";
        
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,pro.getCodProd());
            // executa
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // criando o objeto Usuario
                pro.setCodProd(rs.getInt(1));
                pro.setDescricao(rs.getString(2));
                pro.setPreco(rs.getDouble(3));
                pro.setQtd_inicial(rs.getInt(4));
                pro.setUnidade(rs.getString(5));
                pro.setData(rs.getDate(6));
                pro.setQtd_atual(7);
                // adiciona o usu à lista de usus
            }

            stmt.close();
            c.close();
    
        return pro;

    }
    
    public List<Produtos> lista(String desc) throws SQLException{

        List<Produtos> pro = new ArrayList<>();
        
        String sql = "select * from Produtos where Descricao like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + desc + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Produtos pr = new Produtos(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getInt(5),rs.getDate(6),rs.getInt(7));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
    
    public List<Produtos> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Produtos> prod = new ArrayList<Produtos>();
        
        String sql = "select * from Produtos";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Produtos pro = new Produtos(
                rs.getInt(1),
                rs.getString(2),
                rs.getDouble(3),
                rs.getString(4),
                rs.getInt(5),
                rs.getDate(6),
                rs.getInt(7)
            );
            // adiciona o usu à lista de usus
            prod.add(pro);
        }
        
        rs.close();
        stmt.close();
        return prod;
        
    }

    public List<Produtos> listaInt(int codPro) throws SQLException{

        List<Produtos> pro = new ArrayList<>();
        
        String sql = "select * from Produtos where CodProd like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + codPro + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Produtos pr = new Produtos(
                rs.getInt(1),
                rs.getString(2),
                rs.getDouble(3),
                rs.getString(4),
                rs.getInt(5),
                rs.getDate(6),
                rs.getInt(7));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
}
