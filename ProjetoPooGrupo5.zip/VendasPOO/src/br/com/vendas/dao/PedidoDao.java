package br.com.vendas.dao;

import br.com.vendas.bean.Pedido;
import br.com.vendas.bean.Produtos;
import br.com.vendas.conexao.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PedidoDao {
        private final Connection c;
    
    public PedidoDao() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    

        public Pedido create(Pedido ped)throws SQLException{
        
        String sql = "INSERT INTO Pedidos (CodCliente, nomeCli, Data)VALUES(?,?,?)";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setInt(1, ped.getCodCli());
            stmt.setString(2, ped.getNomeCli());
            stmt.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
            
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                ped.setCodPed(id);
            }
            stmt.close();
            c.close();
            return ped;
    }
        
        public Pedido alterar(Pedido ped)throws SQLException{
        
        String sql = "UPDATE Pedidos SET CodCliente=?, nomeCli=? ,Data=? WHERE CodPed =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setInt(1, ped.getCodCli());
            stmt.setString(2, ped.getNomeCli());
            stmt.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
            stmt.setInt(4, ped.getCodPed());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                ped.setCodPed(id);
            }
            stmt.close();
            c.close();
            return ped;
    }
        public Pedido excluir(Pedido pro)throws SQLException{
        
        String sql = "DELETE FROM Pedidos WHERE CodPed =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


            stmt.setInt(1, pro.getCodPed());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                pro.setCodPed(id);
            }
            stmt.close();
            c.close();
            return pro;
    }
        
        
        public List<Pedido> lista(String codCli) throws SQLException{

        List<Pedido> pro = new ArrayList<>();
        
        String sql = "select * from Pedidos where CodCli like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + codCli + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Pedido pr = new Pedido(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getDate(4));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
    

    
    public List<Pedido> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Pedido> prod = new ArrayList<Pedido>();
        
        String sql = "select * from Pedidos";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Pedido pro = new Pedido(
                rs.getInt(1),
                rs.getInt(2),
                rs.getString(3),
                rs.getDate(4)
            );
            // adiciona o usu à lista de usus
            prod.add(pro);
        }
        
        rs.close();
        stmt.close();
        return prod;
        
    }
    
    public List<Pedido> listaInt(int codPed) throws SQLException{

        List<Pedido> pro = new ArrayList<>();
        
        String sql = "select * from Pedidos where CodPed like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + codPed + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Pedido pr = new Pedido(
                rs.getInt(1),
                rs.getInt(2),
                rs.getString(3),
                rs.getDate(4)
            );
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
}
