package br.com.vendas.dao;

import br.com.vendas.bean.Clientes;
import java.sql.Connection;
import br.com.vendas.conexao.ConexaoDB;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ClienteDao {
    
    private final Connection c;
    
    public ClienteDao() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDB().getConnection();
    }
    
    public Clientes create(Clientes cli)throws SQLException{
        
        String sql = "INSERT INTO Clientes (Nome,Ender,Bairro,Cidade,CEP,UF,Email,Fone,Celular)VALUES(?,?,?,?,?,?,?,?,?)";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            //stmt = con.prepareStatement("INSERT INTO Clientes (Nome,Ender,Bairro,Cidade,CEP,UF,Email,Fone,Celular)VALUES(?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, cli.getNome());
            stmt.setString(2, cli.getEndereco());
            stmt.setString(3, cli.getBairro());
            stmt.setString(4, cli.getCidade());
            stmt.setString(5, cli.getCep());
            stmt.setString(6, cli.getUf());
            stmt.setString(7, cli.getEmail());
            stmt.setString(8, cli.getFone());
            stmt.setString(9, cli.getCelular());
            
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                cli.setCodCli(id);
            }
            stmt.close();
            c.close();
            return cli;        
         
    }
    
        public Clientes alterar(Clientes cli)throws SQLException{
        
        String sql = "UPDATE Clientes SET Nome=?,Ender=?,Bairro=?,Cidade=?,CEP=?,UF=?,Email=?,Fone=?,Celular=? WHERE Codcli =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


        
            stmt.setString(1, cli.getNome());
            stmt.setString(2, cli.getEndereco());
            stmt.setString(3, cli.getBairro());
            stmt.setString(4, cli.getCidade());
            stmt.setString(5, cli.getCep());
            stmt.setString(6, cli.getUf());
            stmt.setString(7, cli.getEmail());
            stmt.setString(8, cli.getFone());
            stmt.setString(9, cli.getCelular());
            stmt.setInt(10, cli.getCodCli());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                cli.setCodCli(id);
            }
            stmt.close();
            c.close();
            return cli;
    }
        public Clientes excluir(Clientes cli)throws SQLException{
        
        String sql = "DELETE FROM Clientes WHERE Codcli =?";
        
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);


            stmt.setInt(1, cli.getCodCli());
            stmt.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso");
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                cli.setCodCli(id);
            }
            stmt.close();
            c.close();
            return cli;
    }
        
        
    
    public List<Clientes> lista(String nome) throws SQLException{

        List<Clientes> pro = new ArrayList<>();
        
        String sql = "select * from Clientes where Nome like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + nome + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Clientes pr = new Clientes(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getString(9),
                    rs.getString(10));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
    public List<Clientes> listaInt(int codCli) throws SQLException{

        List<Clientes> pro = new ArrayList<>();
        
        String sql = "select * from Clientes where Codcli like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + codCli + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            
            Clientes pr = new Clientes(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getString(9),
                    rs.getString(10));
            
            pro.add(pr);
        }
        
        rs.close();
        stmt.close();
        return pro;
        
    }
    
    public List<Clientes> listaTodos() throws SQLException{
         // usus: array armazena a lista de registros

        List<Clientes> prod = new ArrayList<Clientes>();
        
        String sql = "select * from Clientes";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            Clientes pro = new Clientes(
                    rs.getInt(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    rs.getString(9),
                    rs.getString(10));
            
            // adiciona o usu à lista de usus
            prod.add(pro);
        }
        
        rs.close();
        stmt.close();
        return prod;
        
    }

        
}