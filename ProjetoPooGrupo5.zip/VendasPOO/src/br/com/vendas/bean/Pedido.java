package br.com.vendas.bean;

import java.util.Date;

public class Pedido {
    private int codPed, codCli;
    String nomeCli;
    Date data;

    public Pedido(int codCli, String nomeCli) {
        this.codCli = codCli;
        this.nomeCli = nomeCli;
    }

    public Pedido(int codPed, int codCli) {
        this.codPed = codPed;
        this.codCli = codCli;
    }

    public Pedido(int codCli, Date data) {
        this.codCli = codCli;
        this.data = data;
    }

    public Pedido(int codPed, int codCli, String nomeCli, Date data) {
        this.codPed = codPed;
        this.codCli = codCli;
        this.nomeCli = nomeCli;
        this.data = data;
    }

    public Pedido() {
    }

    
    
    
    public int getCodPed() {
        return codPed;
    }

    public void setCodPed(int codPed) {
        this.codPed = codPed;
    }

    public int getCodCli() {
        return codCli;
    }

    public void setCodCli(int codCli) {
        this.codCli = codCli;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }
    
    

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return ("Pedido: " + getCodPed()+" nome cliente: " + getNomeCli());
    }
    
    
    
}
