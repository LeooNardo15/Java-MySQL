
package br.com.vendas.bean;

import java.util.Date;

public class Produtos {
    private int codProd, qtd_inicial, qtd_atual;
    private String descricao, unidade;
    private double preco;
    private Date data;

    public Produtos(int codProd, String descricao, double preco, String unidade, int qtd_inicial, Date data, int qtd_atual) {
        this.codProd = codProd;
        this.qtd_inicial = qtd_inicial;
        this.qtd_atual = qtd_atual;
        this.descricao = descricao;
        this.unidade = unidade;
        this.preco = preco;
        this.data = data;
    }
    
    public Produtos(String descricao, double preco, String unidade, int qtd_inicial, int qtd_atual) {
        this.qtd_inicial = qtd_inicial;
        this.qtd_atual = qtd_atual;
        this.descricao = descricao;
        this.unidade = unidade;
        this.preco = preco;
    }

    
    
    public Produtos() {
        
    }
    
    
    public int getCodProd() {
        return codProd;
    }

    public void setCodProd(int codProd) {
        this.codProd = codProd;
    }

    public int getQtd_inicial() {
        return qtd_inicial;
    }

    public void setQtd_inicial(int qtd_inicial) {
        this.qtd_inicial = qtd_inicial;
    }

    public int getQtd_atual() {
        return qtd_atual;
    }

    public void setQtd_atual(int qtd_atual) {
        this.qtd_atual = qtd_atual;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return ("Produto: " + getDescricao() + ", id:" + getCodProd());
    }
    
    
    
}
