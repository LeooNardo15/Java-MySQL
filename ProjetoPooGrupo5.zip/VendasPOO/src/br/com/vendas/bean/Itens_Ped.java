package br.com.vendas.bean;

public class Itens_Ped {
    private int codPed, codProd, qtd;
    private String nomeCli, prodDesc;

    public Itens_Ped(int codPed, int codProd, String nomeCli, String prodDesc, int qtd) {
        this.codPed = codPed;
        this.codProd = codProd;
        this.qtd = qtd;
        this.nomeCli = nomeCli;
        this.prodDesc = prodDesc;
    }

    public Itens_Ped() {

    }
    
    

    public int getCodPed() {
        return codPed;
    }

    public void setCodPed(int codPed) {
        this.codPed = codPed;
    }

    public int getCodProd() {
        return codProd;
    }

    public void setCodProd(int codProd) {
        this.codProd = codProd;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public String getProdDesc() {
        return prodDesc;
    }

    public void setProdDesc(String prodDesc) {
        this.prodDesc = prodDesc;
    }
    
        
}
